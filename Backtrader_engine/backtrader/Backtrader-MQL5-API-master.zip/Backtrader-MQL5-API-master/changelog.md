### 11th January 2020

- add support for multiple datastreams in parallel for any combination of symbols and timeframes
- add support for tick data
- add support for ask price
- add support for direct download as CSV files
- add parameter options for `host`, `debug` and `datatimeout`
